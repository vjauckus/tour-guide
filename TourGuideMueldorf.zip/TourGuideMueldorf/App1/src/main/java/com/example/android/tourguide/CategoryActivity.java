package com.example.android.tourguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by veronika on 06.02.17.
 */

public class CategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tour_guide_categories_list);


        //find the view that show the category Restaurants
        TextView restaurants = (TextView) findViewById(R.id.restaurants);
        ImageView imageViewRestaurant=(ImageView) findViewById(R.id.image_restaurant);

        imageViewRestaurant.setImageResource(R.drawable.restaurant);

        // set ClickListener on that View

        restaurants.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent restaurantIntent= new Intent(CategoryActivity.this,RestaurantActivity.class);

                Toast.makeText(CategoryActivity.this, "Open the list of restaurants", Toast.LENGTH_SHORT).show();
                startActivity(restaurantIntent);
            }
        });

        //find the view that show the category Events
        TextView event = (TextView) findViewById(R.id.event);

        ImageView imageViewEvent=(ImageView) findViewById(R.id.image_event);

        imageViewEvent.setImageResource(R.drawable.publicfestival);

        // set ClickListener on that View

        event.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent eventIntent= new Intent(CategoryActivity.this,EventActivity.class);

                startActivity(eventIntent);
            }
        });
        //find the view that show the category sport
        TextView sport = (TextView) findViewById(R.id.sport);

        ImageView imageViewSport=(ImageView) findViewById(R.id.image_sport);

        imageViewSport.setImageResource(R.drawable.swimming);

        // set ClickListener on that View

        sport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sportIntent= new Intent(CategoryActivity.this,SportActivity.class);

                startActivity(sportIntent);
            }
        });

        //find the view that show the category Events
        TextView shopping = (TextView) findViewById(R.id.shopping);

        ImageView imageViewShopping=(ImageView) findViewById(R.id.image_shopping);

        imageViewShopping.setImageResource(R.drawable.shopping);

        // set ClickListener on that View

        shopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shoppingIntent= new Intent(CategoryActivity.this,ShoppingActivity.class);

                startActivity(shoppingIntent);
            }
        });
    }
}
