package com.example.android.tourguide;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by veronika on 02.02.17.
 */

public class EventActivity extends AppCompatActivity {

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.word_list);

    final ArrayList<TourGuideWord> event=new ArrayList<TourGuideWord>();

    event.add(new TourGuideWord("Music Night","The entire old town transforms into a festival. Culinary delights meet music of all styles ... food specialties take center stage for many of the visitors.",R.drawable.musicnight));
    event.add(new TourGuideWord("Old town festival","The Summer Festival is a elegant open-air party. Thousands of visitors come every year to enjoy the festival's unique summer atmosphere.",R.drawable.altstadtfest));
    event.add(new TourGuideWord("Concerts in the 'Haberkasten'","Join amazing concerts of groups all around the world who present their skills on the stage which has a very old and interesting background.",R.drawable.haberkasten,"www.inn-salzach-ticket.de/spielstaetten/haberkasten"));
    event.add(new TourGuideWord("Concerts in the 'Stadtsaal'","Exciting concerts in city hall showing programs of all kind. They present ballet, musicals, theatre, bands and orchestra's music.",R.drawable.stadtsaal));
    event.add(new TourGuideWord("Music in church","Many old churches with attractive history and super acoustic invite you.",R.drawable.churchmusic));
    event.add(new TourGuideWord("Public Theatre","Many interesting culture and theatre stories are waiting for you.",R.drawable.kulturschuppen));
    event.add(new TourGuideWord("Public festival","The little son of Munich's 'Oktoberfest' takes place in Mühldorf! Get the buzz when you fly high on one of the carousels or enjoy the view from the ferris wheel. It's the festival of the year for the whole family.",R.drawable.publicfestival));
    event.add(new TourGuideWord("Cinema'Hollywood am Inn'","Of course, even the best home cinema can not replace the atmosphere of a real cinema. Visit our Hollywood, you will be amazed...",R.drawable.kino,"http://hollywoodaminn.de"));


    // Create an {@link ArrayAdapter}, whose data source is a list of Strings. The
    // adapter knows how to create layouts for each item in the list, using the
    // simple_list_item_1.xml layout resource defined in the Android framework.
    // This list item layout contains a single {@link TextView}, which the adapter will set to
    // display a single word.
    TourGuideWordAdapter itemsAdapter =
            new TourGuideWordAdapter(this, event,R.color.category_event);

    // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
    // There should be a {@link ListView} with the view ID called list, which is declared in the
    // activity_numbers.xml layout file.
    ListView listView = (ListView) findViewById(R.id.list);

    // Make the {@link ListView} use the {@link ArrayAdapter} we created above, so that the
    // {@link ListView} will display list items for each word in the list of words.
    // Do this by calling the setAdapter method on the {@link ListView} object and pass in
// 1 argument, which is the {@link ArrayAdapter} with the variable name itemsAdapter.

    listView.setAdapter(itemsAdapter);

    // Set a click listener to open the link when the list item is clicked on
    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

            TourGuideWord myEvent = event.get(position);


            if (myEvent.hasLink()) {
                // Get the {@link Word} object at the given position the user clicked on
                Log.v("ShoppingActivity","Start open link / OK");

                String url=myEvent.getMyLink();

                if (url.startsWith("www.") && !url.startsWith("http")) {
                    url= "http://"+ url;
                }
                else if(!url.startsWith("www.") && !url.startsWith("http")){
                    url= "http://"+ url;
                }
                Intent i =new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));

                startActivity(i);
            }
        }
    });

}
}
