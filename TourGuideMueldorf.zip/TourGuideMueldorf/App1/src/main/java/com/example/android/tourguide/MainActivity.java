package com.example.android.tourguide;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tour_guide_main);


        //find the button to see the tips
        Button intro = (Button) findViewById(R.id.button_start);

        // set ClickListener on that View

        intro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent introIntent= new Intent(MainActivity.this,CategoryActivity.class);

                Toast.makeText(MainActivity.this, "Open the list of categories", Toast.LENGTH_SHORT).show();
                startActivity(introIntent);
            }
        });

        //find the button Contact
        TextView contact=(TextView) findViewById(R.id.contact);
        contact.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent emailIntent= new Intent(Intent.ACTION_SENDTO);
                        emailIntent.setData(Uri.parse("mailto:info@art-webwork.de"));
                        emailIntent.putExtra(emailIntent.EXTRA_SUBJECT,"Message from TourGuide");

                        if (emailIntent.resolveActivity(getPackageManager()) != null) {
                            startActivity(emailIntent);
                        }


                    }
                }
        );

        //find the button Location
        TextView location=(TextView) findViewById(R.id.location);

        location.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent showLocationIntent= new Intent(Intent.ACTION_VIEW);
                        showLocationIntent.setData(Uri.parse("geo:48.245772,12.52199"));


                        if (showLocationIntent.resolveActivity(getPackageManager()) != null) {
                            startActivity(showLocationIntent);
                        }


                    }
                }
        );


    }
}
