package com.example.android.tourguide;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by veronika on 02.02.17.
 */

public class RestaurantActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Allow Up Action to Parent Activity: MiwokMainActivity
      //  getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // getActionBar().setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.word_list);

        final ArrayList<TourGuideWord> restaurants=new ArrayList<TourGuideWord>();

        restaurants.add(new TourGuideWord("Restaurant 'Taverna Metheora'","Traditional greek restaurant invites you to culinary delights.",R.drawable.restaurant, "Innere Neumarkter Str. 2","5pm - 0:30am"));
        restaurants.add(new TourGuideWord("Restaurant 'Wasserschlössel'","Fine restaurant directly at the park with very excellent food and culinary specialties.",R.drawable.wasserschloessel,"http://www.wasserschloessl.de/restaurant/"));
        restaurants.add(new TourGuideWord("Restaurant 'Athen'","Nice greek restaurant. Visiting the recommendable restaurant, and try some specialities.",R.drawable.lunch,"www.restaurant-athen.de"));
        restaurants.add(new TourGuideWord("Café 'Venezia'","Nice italian cafe at the town square.",R.drawable.venezia,"Stadtpl. 53","8am - 11pm"));
        restaurants.add(new TourGuideWord("Café 'Cappuccino'","Exciting italian cafe at the town square.",R.drawable.cappuccino,"Stadtpl. 47","8am - 11pm"));
        restaurants.add(new TourGuideWord("Café 'La Vivre'","Café Vinothek Bistro La Vivre, a piece of France in Bavaria!",R.drawable.lavivre,"Stadtplatz 78, Hans-Sachs-Passage","Tu: 5pm- 12pm, We-So: 9.30am – 12pm, Mo: close"));

        // Create an {@link ArrayAdapter}, whose data source is a list of Strings. The
        // adapter knows how to create layouts for each item in the list, using the
        // simple_list_item_1.xml layout resource defined in the Android framework.
        // This list item layout contains a single {@link TextView}, which the adapter will set to
        // display a single word.
        TourGuideWordAdapter itemsAdapter =
                new TourGuideWordAdapter(this, restaurants, R.color.category_restaurant);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_numbers.xml layout file.
        final ListView listView = (ListView) findViewById(R.id.list);

        // Make the {@link ListView} use the {@link ArrayAdapter} we created above, so that the
        // {@link ListView} will display list items for each word in the list of words.
        // Do this by calling the setAdapter method on the {@link ListView} object and pass in
// 1 argument, which is the {@link ArrayAdapter} with the variable name itemsAdapter.

        listView.setAdapter(itemsAdapter);


        // Set a click listener to open the link when the list item is clicked on
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                TourGuideWord restaurant = restaurants.get(position);

                if (restaurant.hasLink()) {
                    // Get the {@link Word} object at the given position the user clicked on
                    Log.v("RestaurantActivity","Start open restaurant list / OK");

                    String url=restaurant.getMyLink();

                    if (url.startsWith("www.") && !url.startsWith("http")) {
                        url= "http://"+ url;
                    }
                    else if(!url.startsWith("www.") && !url.startsWith("http")){
                        url= "http://"+ url;
                    }
                    Intent i =new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));

                    startActivity(i);
                }



            }
        });




    }
}
