package com.example.android.tourguide;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by veronika on 02.02.17.
 */

public class ShoppingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.word_list);

        final ArrayList<TourGuideWord> shopping = new ArrayList<TourGuideWord>();

        shopping.add(new TourGuideWord("H & M","Nice shopping for all occasions",R.drawable.hm,"www.hm.com/hm.com"));
        shopping.add(new TourGuideWord("K & L","Exciting shopping for all occasions",R.drawable.kl,"https://www.kl-ruppert.de/Filialfinder/Muehldorf.html"));
        shopping.add(new TourGuideWord("Intersport","Excellent sport clothes in the middle of the town",R.drawable.intersport));
        shopping.add(new TourGuideWord("Country Line","Traditional bavarian looks. 'Dirndl' for the women and 'Lederhosn' for the boys.",R.drawable.countryline,"http://www.country-line.de/firma.htm"));
        shopping.add(new TourGuideWord("Mode Komm","Only the best for your wedding or celebration!",R.drawable.modekomm,"http://www.mode-komm.de"));
        shopping.add(new TourGuideWord("Hell","Fine clothes for elegant women.",R.drawable.hell));

        // Create an {@link ArrayAdapter}, whose data source is a list of Strings. The
        // adapter knows how to create layouts for each item in the list, using the
        // simple_list_item_1.xml layout resource defined in the Android framework.
        // This list item layout contains a single {@link TextView}, which the adapter will set to
        // display a single word.
        TourGuideWordAdapter itemsAdapter = new TourGuideWordAdapter(this,shopping,R.color.category_shopping);

        ListView listView= (ListView) findViewById(R.id.list);

        // Make the {@link ListView} use the {@link ArrayAdapter} we created above, so that the
        // {@link ListView} will display list items for each word in the list of words.
        // Do this by calling the setAdapter method on the {@link ListView} object and pass in
// 1 argument, which is the {@link ArrayAdapter} with the variable name itemsAdapter.

        listView.setAdapter(itemsAdapter);

        // Set a click listener to open the link when the list item is clicked on
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                TourGuideWord shop = shopping.get(position);

                if (shop.hasLink()) {
                    // Get the {@link Word} object at the given position the user clicked on

                    String url=shop.getMyLink();
                    Log.v("ShoppingActivity","Start open link / My link is: "+url);

                    if (url.startsWith("www.") && !url.startsWith("http")) {
                        url= "http://"+ url;
                    }
                    else if(!url.startsWith("www.") && !url.startsWith("http")){
                        url= "http://"+ url;
                    }
                    Intent i =new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));

                    startActivity(i);
                }

            }
        });




    }
}


