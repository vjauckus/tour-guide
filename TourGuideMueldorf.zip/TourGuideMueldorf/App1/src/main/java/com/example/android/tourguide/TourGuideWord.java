package com.example.android.tourguide;

/**
 * Created by veronika on 07.02.17.
 *  1 list item is object for WordAdapter
 */

public class TourGuideWord {

    private String myItemName;


    //negativ Constant, because all Resource Ids are positiv
    private  static final int NO_IMAGE_PROVIDED= -1;
    private static final  String NO_LINK_PROVIDED = null;
    private static final  String NO_ADDRESS_PROVIDED = null;
    private static final  String NO_OPEN_HOURS_PROVIDED = null;
    private int myImageId = NO_IMAGE_PROVIDED;

    private String myAdress= NO_ADDRESS_PROVIDED;
    private String myOpenHours= NO_OPEN_HOURS_PROVIDED;

    private String myInfo;

    private String myLink = NO_LINK_PROVIDED;

    /**
     * Constructor 1
     * now not in use
     * @param itemName
     * @param mInfo a short Info
     */

    public TourGuideWord(String itemName,String mInfo){

        myItemName= itemName;
        myInfo = mInfo;
    }

    /**
     * Constructor 2
     * @param itemName  in the list of category
     * @param ImageId for a photo
     * @param mInfo a short Info
     */

    public TourGuideWord(String itemName, String mInfo,int ImageId){

        myItemName= itemName;
        myInfo=mInfo;
        myImageId = ImageId;
    }

    /**
     * Constructor 3
     * @param itemName
     * @param mInfo
     * @param ImageId
     * @param mLink a link to web side if available
     */
    public TourGuideWord(String itemName, String mInfo,int ImageId,String mLink){

        myItemName= itemName;
        myInfo=mInfo;
        myImageId = ImageId;
        myLink = mLink;
    }

    /**
     * Constructor 4
     * @param itemName
     * @param mInfo a short Info
     * @param ImageId for a photo
     * @param mAdress
     * @param mOpenHours
     */
    public TourGuideWord(String itemName, String mInfo,int ImageId,String mAdress,String mOpenHours){

        myItemName= itemName;
        myInfo=mInfo;
        myImageId = ImageId;
        myAdress = mAdress;
        myOpenHours = mOpenHours;
    }
    /**
     * Method ot return Name of item
     * @return
     */
    public String getMyItemName(){

        return myItemName;
    }
  /**
     * Method ot return Name of object
     * @return
     */
    public String getMyInfo(){

        return myInfo;
    }

    /**
     * Method to return drawable Image Id, integer
     * @return
     */
    public int getMyImageId(){

        return myImageId;
    }

    /**
     * Method to return drawable Link Id, String
     * @return
     */
    public String getMyLink(){

        return myLink;
    }

    /**
     * Method to return Address, String
     * @return
     */
    public String getMyAdress(){

        return myAdress;
    }

    /**
     * Method to return Open Hours, String
     * @return
     */
    public String getMyOpenHours(){

        return myOpenHours;
    }
    /**
     function that show, if image is there or not . If image is not there then mImageResourceID=NO_IMAGE_PROVided and hasImage == false

     * @return  true or false
     */
    public boolean hasImage(){

        return myImageId != NO_IMAGE_PROVIDED;    }

    /**
     function that show, if link is there or not . If link is not there then myLinkID=NO_Link_PROVided and hasLink == false

     * @return  true or false
     */
    public boolean hasLink(){

        return myLink != NO_LINK_PROVIDED;    }

    /**
     * function that show if address is available
     * @return
     **/
    public boolean hasAddress(){

        return myAdress != NO_ADDRESS_PROVIDED;    }
    /**
     * function that show additional Info
     * @return
     **/
    public boolean hasOpenHours(){

        return myOpenHours != NO_OPEN_HOURS_PROVIDED;    }

}
