package com.example.android.tourguide;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by veronika on 07.02.17.
 */

public class TourGuideWordAdapter extends ArrayAdapter<TourGuideWord>{

    private int mySiteBackgroundColor = -1;

    /**
     * This is our own custom constructor (it doesn't mirror a superclass constructor).
     * The context is used to inflate the layout file, and the list is the data we want
     * to populate into the lists.
     *
     * @param context        The current context. Used to inflate the layout file.
     * @param words A List of words as objects to display in a list
     */



    public TourGuideWordAdapter(Activity context, ArrayList<TourGuideWord> words, int myColor) {
        // Here, we initialize the ArrayAdapter's internal storage for the context and the list.
        // the second argument is used when the ArrayAdapter is populating a single TextView.
        // Because this is a custom adapter for two TextViews , the adapter is not
        // going to use this second argument, so it can be any value. Here, we used 0.
        super(context, 0, words);
        mySiteBackgroundColor = myColor;
    }

    /**
     * Provides a view for an AdapterView (ListView, GridView, etc.)
     *
     * @param position The position in the list of data that should be displayed in the
     *                 list item view.
     * @param convertView The recycled view to populate.
     * @param parent The parent ViewGroup that is used for inflation.
     * @return The View for the position in the AdapterView.
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Get the {@link Word} object located at this position in the list
        final TourGuideWord currentWord = getItem(position);

        // Check if the existing view is being reused, otherwise inflate the view
        //parent ist ListView
        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item_category, parent, false);
        }

        // Find the TextView in the list_item.xml layout with the ID version_name
        TextView categorieTextView = (TextView) listItemView.findViewById(R.id.categorie_text_view);

        categorieTextView.setText(currentWord.getMyItemName());

        // Find the TextView in the list_item.xml layout with the ID version_name
        TextView myInfo = (TextView) listItemView.findViewById(R.id.details_short);

        myInfo.setText(currentWord.getMyInfo());

        listItemView.setBackgroundResource(mySiteBackgroundColor);

        //ImageView
        ImageView imageView=(ImageView) listItemView.findViewById(R.id.image_categorie);

        if(currentWord.hasImage()){
            imageView.setImageResource(currentWord.getMyImageId());
            Log.v("TourGuideWordAdapter","Guide Word Adapter with item "+currentWord.getMyItemName()+" found the Image: "+currentWord.getMyImageId());
        }
        else {
            imageView.setVisibility(View.GONE);
        }

        //TextView with LinkId

        TextView linkView= (TextView) listItemView.findViewById(R.id.link);

        linkView.setText(currentWord.getMyLink());
        linkView.setVisibility(View.GONE);

        //show Address

        TextView addressView= (TextView) listItemView.findViewById(R.id.adress);
        TextView addressHeadingView= (TextView) listItemView.findViewById(R.id.address_heading);

        TextView openHoursView= (TextView) listItemView.findViewById(R.id.open_hours);
        TextView openHoursHeadingView= (TextView) listItemView.findViewById(R.id.open_hours_heading);

        View containerLongInfo=(View) listItemView.findViewById(R.id.container_long_info);

        // Find the Button See more in the list_item_category.xml
        TextView seeMore = (TextView) listItemView.findViewById(R.id.textview_more);
        seeMore.setText("See more");

        seeMore.setVisibility(View.GONE);
        containerLongInfo.setVisibility(View.GONE);

        if (currentWord.hasLink()) {

            Log.v("TourGuideWordAdapter","Guide Word Adapter found the link: "+currentWord.getMyLink());
           seeMore.setVisibility(View.VISIBLE);


        }
        if (currentWord.hasAddress() && currentWord.hasOpenHours()){
            addressView.setText(currentWord.getMyAdress());
            addressHeadingView.setText("Our Address:");
            openHoursView.setText(currentWord.getMyOpenHours());
            openHoursHeadingView.setText("Our open hours :");
            containerLongInfo.setVisibility(View.VISIBLE);
        }

        return listItemView;
}}
